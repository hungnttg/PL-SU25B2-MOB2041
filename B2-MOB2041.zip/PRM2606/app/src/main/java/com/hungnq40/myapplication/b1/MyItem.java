package com.hungnq40.myapplication.b1;

public class MyItem {
    int id;
    int price;
    String info;

    public MyItem(int id, int price, String info) {
        this.id = id;
        this.price = price;
        this.info = info;
    }
}