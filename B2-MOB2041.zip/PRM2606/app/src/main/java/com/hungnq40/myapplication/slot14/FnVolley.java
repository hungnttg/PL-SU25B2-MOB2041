package com.hungnq40.myapplication.slot14;

import android.content.Context;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class FnVolley {
    //doc du lieu dang chuoi
    public void getStringVolley(Context context, TextView textView){
        //1. Tao request
        RequestQueue queue = Volley.newRequestQueue(context);
        //2. URL
        String url = "https://www.google.com";
        //3. Truyen tham so
        //StringRequest(phuongThuc,url,thanhcong,thatbai)
        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //lay ve 1000 ky tu
                textView.setText("Ket qua: "+response.substring(0,1000));
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView.setText(error.getMessage());
            }
        });
        //4.Xu ly request
        queue.add(stringRequest);
    }
    //doc du lieu tu API: mang cua cac doi tuong
    String strKQ = "";
    public void get_Array_objects(Context context,TextView textView){
        strKQ = "";//chuoi chua ket qua
        //1. tao request
        RequestQueue queue = Volley.newRequestQueue(context);
        //2. Url
        String url = "https://hungnttg.github.io/array_json_new.json";
        //3. goi Request: Mang cua cac doi tuong: JsonArrayRequest
        JsonArrayRequest request=new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                //for mang de lay ve doi tuong
                for(int i=0;i<response.length();i++){
                    try {
                        //lay ve 1 doi tuong
                        JSONObject person = response.getJSONObject(i);
                        String name = person.getString("name");
                        String email = person.getString("email");
                        //dua vao chuoi chua ket qua
                        strKQ +="Name: "+name+"\n";
                        strKQ +="Email: "+email+"\n";
                        strKQ +="-----------------------\n";
                    } catch (JSONException e) {
                        throw new RuntimeException(e);
                    }
                }
                textView.setText(strKQ);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView.setText(error.getMessage());
            }
        });
        queue.add(request);//thuc thi request
    }
}
