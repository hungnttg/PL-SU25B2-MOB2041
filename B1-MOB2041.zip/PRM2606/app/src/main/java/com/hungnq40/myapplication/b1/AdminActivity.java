package com.hungnq40.myapplication.b1;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hungnq40.myapplication.R;

import java.util.ArrayList;
import java.util.Random;

public class AdminActivity extends AppCompatActivity {
    DBHelper dbHelper;
    EditText edtInfo, edtPrice;
    Button btnAdd;
    ListView lv;
    ArrayList<String> data;
    ArrayList<Integer> ids;
    ArrayAdapter<String> adapter;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_admin);

        dbHelper = new DBHelper(this);
        //dong sau chi chay 1 lan
        //dbHelper.insertSampleData();

        edtInfo = findViewById(R.id.edtInfo);
        edtPrice = findViewById(R.id.edtPrice);
        btnAdd = findViewById(R.id.btnAdd);
        lv = findViewById(R.id.lv);

        btnAdd.setOnClickListener(v -> {
            addProduct();
        });

        lv.setOnItemClickListener((parent,
                                   view, position, id) -> {
            deleteProduct(ids.get(position));
        });

        loadData();

    }
    void loadData() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT styleid, product_additional_info, price FROM mytable",
                null);

        data = new ArrayList<>();
        ids = new ArrayList<>();
        while (c.moveToNext()) {
            ids.add(c.getInt(0));
            data.add(c.getString(1) + " - Giá: " + c.getInt(2));
        }
        c.close();

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, data);
        lv.setAdapter(adapter);
    }

    void addProduct() {
        String info = edtInfo.getText().toString();
        String price = edtPrice.getText().toString();
        if (info.isEmpty() || price.isEmpty()) return;

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int styleid = new Random().nextInt(99999999) + 1000000;
        db.execSQL("INSERT INTO mytable(styleid, search_image, brands_filter_facet, " +
                        "price, product_additional_info) " +
                        "VALUES (?, '', 'Nike', ?, ?)",
                new Object[]{styleid, Integer.parseInt(price), info});
        loadData();
        edtInfo.setText("");
        edtPrice.setText("");
    }

    void deleteProduct(int styleid) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL("DELETE FROM mytable WHERE styleid = ?", new Object[]{styleid});
        loadData();
    }
}