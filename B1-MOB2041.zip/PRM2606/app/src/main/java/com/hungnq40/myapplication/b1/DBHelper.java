package com.hungnq40.myapplication.b1;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(Context context) {
        super(context, "a6.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS mytable (" +
                "search_image TEXT NOT NULL," +
                "styleid INTEGER PRIMARY KEY," +
                "brands_filter_facet TEXT NOT NULL," +
                "price INTEGER NOT NULL," +
                "product_additional_info TEXT NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS mytable");
        onCreate(db);
    }

    public void insertSampleData() {
        SQLiteDatabase db = this.getWritableDatabase();

        String sql = "INSERT INTO mytable " +
                "(search_image, styleid, brands_filter_facet, price, product_additional_info) VALUES " +
                "('http://a.jpg', 10271347, 'Nike', 3551, 'Men NSW CE DRI-FIT Tracksuit')," +
                "('http://b.jpg', 10588800, 'Nike', 2396, 'Men NSW PLAYRS Solid Joggers')," +
                "('http://assets.myntassets.com/assets/images/10609404/2019/9/28/6c49897e-51f9-4e4d-a5ee-9675029133cc1569655735440-Nike-Sportswear-Club-1711569655734185-1.jpg', 10609404, 'Nike', 1996, 'Dri-FIT CLUB JSY Solid Joggers')," +
                "('http://assets.myntassets.com/assets/images/10714242/2019/11/29/57e3a3c3-a7a2-405b-a596-3246d60ff0dc1575017786189-Nike-Men-Grey-DOWNSHIFTER-7-Running-Shoes-741575017783904-1.jpg', 10714242, 'Nike', 3196, 'Men DOWNSHIFTER Running Shoes')," +
                "('http://1.jpg', 10714390, 'Nike', 5096, 'Retaliation 2 Training Shoes');";

        db.execSQL(sql);
    }
}


